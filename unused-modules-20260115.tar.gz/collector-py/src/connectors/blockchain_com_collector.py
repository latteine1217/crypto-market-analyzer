# BTC 地址分層追蹤 - 替代資料來源方案

> **目的**: 提供除 Glassnode 外的其他資料收集方式  
> **更新時間**: 2026-01-15

---

## 📊 資料來源對比

| 來源 | 免費額度 | 資料品質 | 更新頻率 | 難度 | 推薦度 |
|------|---------|---------|---------|------|--------|
| **Glassnode API** | 有限 | ⭐⭐⭐⭐⭐ | 1-2h | 簡單 | ⭐⭐⭐⭐⭐ |
| **Blockchain.com API** | ✅ 無限 | ⭐⭐⭐⭐ | 即時 | 簡單 | ⭐⭐⭐⭐ |
| **Bitcoin Core RPC** | ✅ 完全免費 | ⭐⭐⭐⭐⭐ | 即時 | 複雜 | ⭐⭐⭐⭐ |
| **自建爬蟲（區塊瀏覽器）** | ✅ 免費 | ⭐⭐⭐ | 可控 | 非常複雜 | ⭐⭐ |
| **IntoTheBlock API** | 有限 | ⭐⭐⭐⭐ | 1h | 簡單 | ⭐⭐⭐⭐ |

---

## 方案一：Blockchain.com API（推薦 - 免費）

### 優點
✅ **完全免費**，無請求限制  
✅ 提供 Bitcoin 地址餘額分布  
✅ 有官方 API 文檔，穩定可靠  
✅ 即時資料，無延遲  

### 缺點
⚠️ 需要自己聚合地址分層資料  
⚠️ API 回傳格式較原始，需要處理  

### API 端點

**1. 地址餘額分布**
```
GET https://blockchain.info/charts/balance-distribution?timespan=1days&format=json
```

**回傳範例**:
```json
{
  "name": "Balance Distribution",
  "values": [
    {"x": 1705276800, "y": 48500000},  // 0-0.001 BTC: 4850萬地址
    {"x": 1705276800, "y": 850000}     // 0.001-0.01 BTC: 85萬地址
  ]
}
```

**2. 富豪榜（Top Addresses）**
```
GET https://blockchain.info/q/addressbalance/{address}
```

### 實作方案

<function_calls>
<invoke name="write">
<parameter name="content">"""
Blockchain.com API Collector
免費的 BTC 地址分層資料收集器
"""
import aiohttp
import asyncio
from datetime import datetime
from decimal import Decimal
from typing import List, Dict, Any, Optional
from loguru import logger


class BlockchainComCollector:
    """
    Blockchain.com API 收集器（免費）
    
    資料來源: https://www.blockchain.com/explorer/api
    """
    
    BASE_URL = "https://blockchain.info"
    
    # 地址分層定義（需要自己對應）
    TIER_MAPPING = {
        '0-1': {'min': 0, 'max': 1},
        '1-10': {'min': 1, 'max': 10},
        '10-100': {'min': 10, 'max': 100},
        '100-1K': {'min': 100, 'max': 1000},
        '1K-10K': {'min': 1000, 'max': 10000},
        '10K+': {'min': 10000, 'max': None},
    }
    
    def __init__(self, timeout: int = 30):
        """初始化收集器（無需 API key）"""
        self.timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """取得 HTTP session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        return self._session
    
    async def close(self):
        """關閉 session"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def fetch_balance_distribution(self) -> Dict[str, Any]:
        """
        獲取地址餘額分布
        
        Returns:
            {
                'timestamp': datetime,
                'tiers': {
                    '0-1': {'address_count': 48500000, 'estimated_balance': Decimal(...)},
                    ...
                }
            }
        """
        url = f"{self.BASE_URL}/charts/balance-distribution"
        params = {
            'timespan': '1days',
            'format': 'json'
        }
        
        session = await self._get_session()
        
        try:
            async with session.get(url, params=params) as response:
                response.raise_for_status()
                data = await response.json()
                
                logger.info(f"✅ Blockchain.com API: 成功獲取地址分布資料")
                
                return await self._parse_distribution(data)
        
        except Exception as e:
            logger.error(f"❌ Blockchain.com API 錯誤: {e}")
            raise
    
    async def _parse_distribution(self, raw_data: Dict) -> Dict[str, Any]:
        """
        解析 Blockchain.com 回傳的分布資料
        
        Note: Blockchain.com 的分層定義與我們不同，需要對應
        """
        # Blockchain.com 的分層（範例）
        # 實際需要查看 API 文檔的完整分層定義
        blockchain_tiers = {
            '0-0.001': {'count': 0, 'balance': 0},
            '0.001-0.01': {'count': 0, 'balance': 0},
            '0.01-0.1': {'count': 0, 'balance': 0},
            '0.1-1': {'count': 0, 'balance': 0},
            '1-10': {'count': 0, 'balance': 0},
            '10-100': {'count': 0, 'balance': 0},
            '100-1000': {'count': 0, 'balance': 0},
            '1000-10000': {'count': 0, 'balance': 0},
            '10000+': {'count': 0, 'balance': 0},
        }
        
        # TODO: 實際解析 raw_data，填充 blockchain_tiers
        # 這需要根據 Blockchain.com 實際 API 格式調整
        
        # 將 Blockchain.com 分層對應到我們的分層
        our_tiers = {}
        
        # 0-1 BTC = 0-0.001 + 0.001-0.01 + 0.01-0.1 + 0.1-1
        our_tiers['0-1'] = {
            'address_count': (
                blockchain_tiers['0-0.001']['count'] +
                blockchain_tiers['0.001-0.01']['count'] +
                blockchain_tiers['0.01-0.1']['count'] +
                blockchain_tiers['0.1-1']['count']
            ),
            'balance': Decimal('0')  # 需要實際計算
        }
        
        # 1-10 BTC
        our_tiers['1-10'] = {
            'address_count': blockchain_tiers['1-10']['count'],
            'balance': Decimal(str(blockchain_tiers['1-10']['balance']))
        }
        
        # ... 其他分層
        
        return {
            'timestamp': datetime.now(),
            'tiers': our_tiers
        }
    
    async def fetch_richlist(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        獲取富豪榜（前 N 名地址）
        
        Note: Blockchain.com 沒有直接的富豪榜 API
        需要使用第三方服務或自建索引
        """
        logger.warning("Blockchain.com 沒有直接的富豪榜 API")
        return []


# ============================================
# 測試程式
# ============================================

async def test_blockchain_com_collector():
    """測試 Blockchain.com Collector"""
    collector = BlockchainComCollector()
    
    try:
        logger.info("=" * 80)
        logger.info("測試 Blockchain.com API")
        logger.info("=" * 80)
        
        # 測試地址分布
        data = await collector.fetch_balance_distribution()
        
        logger.info(f"\n時間戳: {data['timestamp']}")
        logger.info(f"分層數: {len(data['tiers'])}")
        
        for tier_name, tier_data in data['tiers'].items():
            logger.info(
                f"  {tier_name:10s}: "
                f"{tier_data['address_count']:>12,} addresses, "
                f"{tier_data['balance']:>15,.2f} BTC"
            )
    
    except Exception as e:
        logger.error(f"❌ 測試失敗: {e}")
    
    finally:
        await collector.close()


if __name__ == "__main__":
    asyncio.run(test_blockchain_com_collector())
