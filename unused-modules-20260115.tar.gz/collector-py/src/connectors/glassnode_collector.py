"""
Glassnode API Collector
用於收集 BTC 地址分層分布資料

API 文檔: https://docs.glassnode.com/
"""
import aiohttp
import asyncio
from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Dict, Any, Optional
from loguru import logger


class GlassnodeCollector:
    """
    Glassnode API 收集器
    
    主要功能：
    - 收集 BTC 地址分層分布（Supply Distribution）
    - 收集地址餘額變動
    - 支援速率限制與錯誤重試
    """
    
    BASE_URL = "https://api.glassnode.com/v1/metrics"
    
    # 地址分層定義（簡化版：4 層）
    # 100+ 層級需要合併 Glassnode 的 100-1k, 1k-10k, 10k_100k 三個指標
    TIER_DEFINITIONS = {
        '0-1': {'min': 0, 'max': 1, 'metric_suffix': '0_001'},
        '1-10': {'min': 1, 'max': 10, 'metric_suffix': '1_10'},
        '10-100': {'min': 10, 'max': 100, 'metric_suffix': '10_100'},
        '100+': {'min': 100, 'max': None, 'metric_suffixes': ['100_1k', '1k_10k', '10k_100k']},  # 需要合併
    }
    
    def __init__(
        self,
        api_key: str,
        blockchain: str = 'BTC',
        rate_limit: int = 10,  # 每分鐘請求數
        timeout: int = 30
    ):
        """
        初始化 Glassnode Collector
        
        Args:
            api_key: Glassnode API 金鑰
            blockchain: 區塊鏈名稱（BTC, ETH）
            rate_limit: 每分鐘請求數限制
            timeout: 請求超時時間（秒）
        """
        self.api_key = api_key
        self.blockchain = blockchain.upper()
        self.rate_limit = rate_limit
        self.timeout = timeout
        
        # 速率限制控制
        self._request_times: List[datetime] = []
        self._lock = asyncio.Lock()
        
        # Session（延遲初始化）
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """取得或建立 HTTP session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={'X-Api-Key': self.api_key},
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        return self._session
    
    async def close(self):
        """關閉 HTTP session"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def _rate_limit_wait(self):
        """速率限制等待"""
        async with self._lock:
            now = datetime.now()
            
            # 移除 1 分鐘前的請求記錄
            self._request_times = [
                t for t in self._request_times 
                if (now - t).total_seconds() < 60
            ]
            
            # 檢查是否超過速率限制
            if len(self._request_times) >= self.rate_limit:
                oldest_request = self._request_times[0]
                wait_time = 60 - (now - oldest_request).total_seconds()
                
                if wait_time > 0:
                    logger.debug(f"速率限制：等待 {wait_time:.1f} 秒")
                    await asyncio.sleep(wait_time)
            
            # 記錄當前請求時間
            self._request_times.append(now)
    
    def _merge_tier_data(self, data_lists: List[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """
        合併多個分層的資料（用於 100+ 層級）
        
        Args:
            data_lists: [[{t: timestamp, v: value}, ...], ...]
        
        Returns:
            [{t: timestamp, v: sum_of_values}, ...]
        """
        if not data_lists or all(not d for d in data_lists):
            return []
        
        # 建立時間戳索引
        timestamp_map: Dict[int, float] = {}
        
        for data_list in data_lists:
            for item in data_list:
                timestamp = item['t']
                value = float(item['v'])
                
                if timestamp in timestamp_map:
                    timestamp_map[timestamp] += value
                else:
                    timestamp_map[timestamp] = value
        
        # 轉回列表格式並排序
        merged = [
            {'t': timestamp, 'v': value}
            for timestamp, value in timestamp_map.items()
        ]
        merged.sort(key=lambda x: x['t'])
        
        return merged
    
    async def _make_request(
        self,
        endpoint: str,
        params: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        發送 API 請求
        
        Args:
            endpoint: API 端點（如 'distribution/balance_addresses'）
            params: 查詢參數
        
        Returns:
            API 響應數據列表
        """
        await self._rate_limit_wait()
        
        url = f"{self.BASE_URL}/{endpoint}"
        params['a'] = self.blockchain  # 添加區塊鏈參數
        
        session = await self._get_session()
        
        try:
            async with session.get(url, params=params) as response:
                response.raise_for_status()
                data = await response.json()
                
                logger.debug(
                    f"✅ Glassnode API: {endpoint} "
                    f"({len(data) if isinstance(data, list) else 1} 筆資料)"
                )
                
                return data if isinstance(data, list) else [data]
                
        except aiohttp.ClientResponseError as e:
            logger.error(f"❌ Glassnode API 錯誤: {e.status} - {e.message}")
            
            # 403: API key 無效或配額用盡
            # 429: 速率限制
            # 404: 端點不存在
            if e.status == 429:
                logger.warning("速率限制超過，等待 60 秒後重試...")
                await asyncio.sleep(60)
                return await self._make_request(endpoint, params)
            
            raise
        
        except Exception as e:
            logger.error(f"❌ 請求失敗: {e}")
            raise
    
    async def fetch_supply_distribution(
        self,
        tier_name: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        interval: str = '24h'
    ) -> List[Dict[str, Any]]:
        """
        獲取特定分層的供應分布
        
        Args:
            tier_name: 分層名稱（'0-1', '1-10', '10-100', '100+'）
            start_date: 開始日期
            end_date: 結束日期
            interval: 時間間隔（'24h', '1h', '1w'）
        
        Returns:
            [{
                't': 1234567890,  # Unix timestamp
                'v': 123456.789   # BTC 數量
            }, ...]
        """
        if tier_name not in self.TIER_DEFINITIONS:
            raise ValueError(f"無效的分層名稱: {tier_name}")
        
        tier_def = self.TIER_DEFINITIONS[tier_name]
        
        # 參數
        params = {
            'i': interval,
            'f': 'JSON',
        }
        
        if start_date:
            params['s'] = int(start_date.timestamp())
        if end_date:
            params['u'] = int(end_date.timestamp())
        
        try:
            # 100+ 層級需要合併多個指標
            if tier_name == '100+':
                metric_suffixes = tier_def['metric_suffixes']
                all_data = []
                
                # 依序獲取 100-1k, 1k-10k, 10k_100k
                for suffix in metric_suffixes:
                    endpoint = f"distribution/balance_{suffix}_sum"
                    data = await self._make_request(endpoint, params)
                    all_data.append(data)
                
                # 合併資料（按時間戳加總）
                merged_data = self._merge_tier_data(all_data)
                return merged_data
            else:
                # 單一指標
                metric_suffix = tier_def['metric_suffix']
                endpoint = f"distribution/balance_{metric_suffix}_sum"
                data = await self._make_request(endpoint, params)
                return data
                
        except Exception as e:
            logger.error(f"獲取 {tier_name} 分層失敗: {e}")
            return []
    
    async def fetch_address_count(
        self,
        tier_name: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        interval: str = '24h'
    ) -> List[Dict[str, Any]]:
        """
        獲取特定分層的地址數量
        
        Args:
            tier_name: 分層名稱（'0-1', '1-10', '10-100', '100+'）
            start_date: 開始日期
            end_date: 結束日期
            interval: 時間間隔
        
        Returns:
            [{
                't': 1234567890,  # Unix timestamp
                'v': 1234         # 地址數量
            }, ...]
        """
        if tier_name not in self.TIER_DEFINITIONS:
            raise ValueError(f"無效的分層名稱: {tier_name}")
        
        tier_def = self.TIER_DEFINITIONS[tier_name]
        
        params = {
            'i': interval,
            'f': 'JSON',
        }
        
        if start_date:
            params['s'] = int(start_date.timestamp())
        if end_date:
            params['u'] = int(end_date.timestamp())
        
        try:
            # 100+ 層級需要合併多個指標
            if tier_name == '100+':
                metric_suffixes = tier_def['metric_suffixes']
                all_data = []
                
                # 依序獲取 100-1k, 1k-10k, 10k_100k
                for suffix in metric_suffixes:
                    endpoint = f"distribution/balance_{suffix}_count"
                    data = await self._make_request(endpoint, params)
                    all_data.append(data)
                
                # 合併資料（按時間戳加總）
                merged_data = self._merge_tier_data(all_data)
                return merged_data
            else:
                # 單一指標
                metric_suffix = tier_def['metric_suffix']
                endpoint = f"distribution/balance_{metric_suffix}_count"
                data = await self._make_request(endpoint, params)
                return data
                
        except Exception as e:
            logger.error(f"獲取 {tier_name} 地址數量失敗: {e}")
            return []
    
    async def fetch_all_tiers_latest(self) -> Dict[str, Dict[str, Any]]:
        """
        獲取所有分層的最新資料
        
        Returns:
            {
                '0-1': {
                    'balance': 123.456,
                    'address_count': 12345678,
                    'timestamp': datetime
                },
                ...
            }
        """
        result = {}
        
        # 只獲取最近 1 天資料（latest）
        end_date = datetime.now()
        start_date = end_date - timedelta(days=2)
        
        for tier_name in self.TIER_DEFINITIONS.keys():
            logger.info(f"📊 正在收集 {tier_name} 分層資料...")
            
            try:
                # 並行獲取餘額與地址數量
                balance_data, count_data = await asyncio.gather(
                    self.fetch_supply_distribution(tier_name, start_date, end_date),
                    self.fetch_address_count(tier_name, start_date, end_date),
                    return_exceptions=True
                )
                
                # 處理異常
                if isinstance(balance_data, Exception):
                    logger.error(f"{tier_name} 餘額資料獲取失敗: {balance_data}")
                    continue
                
                if isinstance(count_data, Exception):
                    logger.error(f"{tier_name} 地址數量獲取失敗: {count_data}")
                    continue
                
                # 取最新一筆資料
                if balance_data and count_data:
                    latest_balance = balance_data[-1]
                    latest_count = count_data[-1]
                    
                    result[tier_name] = {
                        'balance': Decimal(str(latest_balance['v'])),
                        'address_count': int(latest_count['v']),
                        'timestamp': datetime.fromtimestamp(latest_balance['t']),
                    }
                    
                    logger.success(
                        f"✅ {tier_name}: "
                        f"{result[tier_name]['balance']:,.2f} BTC, "
                        f"{result[tier_name]['address_count']:,} addresses"
                    )
                else:
                    logger.warning(f"{tier_name} 無最新資料")
            
            except Exception as e:
                logger.error(f"{tier_name} 資料收集失敗: {e}")
                continue
        
        return result
    
    async def fetch_historical_data(
        self,
        days: int = 7
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        獲取過去 N 天的歷史資料（所有分層）
        
        Args:
            days: 天數
        
        Returns:
            {
                '0-1': [
                    {'timestamp': datetime, 'balance': Decimal, 'address_count': int},
                    ...
                ],
                ...
            }
        """
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        result = {}
        
        for tier_name in self.TIER_DEFINITIONS.keys():
            logger.info(f"📊 收集 {tier_name} 過去 {days} 天資料...")
            
            try:
                # 並行獲取餘額與地址數量
                balance_data, count_data = await asyncio.gather(
                    self.fetch_supply_distribution(tier_name, start_date, end_date),
                    self.fetch_address_count(tier_name, start_date, end_date)
                )
                
                # 合併資料
                if balance_data and count_data:
                    # 建立 timestamp → count 映射
                    count_map = {item['t']: item['v'] for item in count_data}
                    
                    tier_history = []
                    for balance_item in balance_data:
                        ts = balance_item['t']
                        
                        tier_history.append({
                            'timestamp': datetime.fromtimestamp(ts),
                            'balance': Decimal(str(balance_item['v'])),
                            'address_count': int(count_map.get(ts, 0)),
                        })
                    
                    result[tier_name] = tier_history
                    logger.success(f"✅ {tier_name}: {len(tier_history)} 筆歷史資料")
            
            except Exception as e:
                logger.error(f"{tier_name} 歷史資料收集失敗: {e}")
                continue
        
        return result
    
    @staticmethod
    def calculate_daily_change(
        current: Decimal,
        previous: Decimal
    ) -> Decimal:
        """計算每日變動"""
        return current - previous if previous else Decimal('0')


# ============================================
# 測試程式
# ============================================

async def test_glassnode_collector():
    """測試 Glassnode Collector"""
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    api_key = os.getenv('GLASSNODE_API_KEY')
    if not api_key:
        logger.error("請設定 GLASSNODE_API_KEY 環境變數")
        return
    
    collector = GlassnodeCollector(api_key=api_key, blockchain='BTC')
    
    try:
        logger.info("=" * 80)
        logger.info("測試 Glassnode BTC 地址分層收集")
        logger.info("=" * 80)
        
        # 測試 1: 獲取所有分層最新資料
        logger.info("\n[測試 1] 獲取所有分層最新資料")
        latest_data = await collector.fetch_all_tiers_latest()
        
        logger.info("\n📊 最新資料摘要:")
        for tier_name, data in latest_data.items():
            logger.info(
                f"  {tier_name:10s}: "
                f"{data['balance']:>15,.2f} BTC | "
                f"{data['address_count']:>12,} addresses"
            )
        
        # 測試 2: 獲取過去 7 天資料（僅測試一個分層）
        logger.info("\n[測試 2] 獲取 '100-1K' 分層過去 7 天資料")
        historical = await collector.fetch_historical_data(days=7)
        
        if '100-1K' in historical:
            tier_history = historical['100-1K']
            logger.info(f"  共 {len(tier_history)} 筆資料")
            
            # 顯示前 3 筆
            for i, record in enumerate(tier_history[:3], 1):
                logger.info(
                    f"    {i}. {record['timestamp'].strftime('%Y-%m-%d')}: "
                    f"{record['balance']:,.2f} BTC, "
                    f"{record['address_count']:,} addresses"
                )
        
        logger.info("\n✅ 測試完成")
    
    except Exception as e:
        logger.error(f"❌ 測試失敗: {e}")
        raise
    
    finally:
        await collector.close()


if __name__ == "__main__":
    asyncio.run(test_glassnode_collector())
