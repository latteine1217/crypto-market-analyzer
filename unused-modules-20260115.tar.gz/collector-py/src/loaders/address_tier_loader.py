"""
地址分層資料載入器
將 Glassnode 收集的資料寫入 TimescaleDB
"""
import asyncio
import json
from datetime import datetime, date
from decimal import Decimal
from typing import List, Dict, Any, Optional
from loguru import logger
import asyncpg


class AddressTierLoader:
    """
    地址分層資料載入器
    
    負責將 Glassnode 收集的地址分層資料寫入資料庫
    """
    
    def __init__(self, db_config: Dict[str, Any]):
        """
        初始化載入器
        
        Args:
            db_config: 資料庫配置
        """
        self.db_config = db_config
        self.conn_pool: Optional[asyncpg.Pool] = None
        self._tier_id_cache: Dict[str, int] = {}
        self._blockchain_id_cache: Dict[str, int] = {}
    
    async def connect(self):
        """建立資料庫連接池"""
        if self.conn_pool is None:
            self.conn_pool = await asyncpg.create_pool(
                host=self.db_config.get('host', 'localhost'),
                port=self.db_config.get('port', 5432),
                user=self.db_config.get('user', 'crypto'),
                password=self.db_config.get('password', ''),
                database=self.db_config.get('database', 'crypto_db'),
                min_size=2,
                max_size=10,
                command_timeout=60
            )
            logger.info("✅ 資料庫連接池已建立")
            
            # 載入 cache
            await self._load_tier_cache()
            await self._load_blockchain_cache()
    
    async def close(self):
        """關閉資料庫連接池"""
        if self.conn_pool:
            await self.conn_pool.close()
            logger.info("✅ 資料庫連接池已關閉")
    
    async def _load_tier_cache(self):
        """載入分層 ID 快取"""
        async with self.conn_pool.acquire() as conn:
            rows = await conn.fetch("SELECT id, tier_name FROM address_tiers")
            self._tier_id_cache = {row['tier_name']: row['id'] for row in rows}
            logger.debug(f"載入 {len(self._tier_id_cache)} 個分層定義")
    
    async def _load_blockchain_cache(self):
        """載入區塊鏈 ID 快取"""
        async with self.conn_pool.acquire() as conn:
            rows = await conn.fetch("SELECT id, name FROM blockchains")
            self._blockchain_id_cache = {row['name']: row['id'] for row in rows}
            logger.debug(f"載入 {len(self._blockchain_id_cache)} 個區塊鏈定義")
    
    def _get_tier_id(self, tier_name: str) -> Optional[int]:
        """取得分層 ID"""
        return self._tier_id_cache.get(tier_name)
    
    def _get_blockchain_id(self, blockchain_name: str) -> Optional[int]:
        """取得區塊鏈 ID"""
        return self._blockchain_id_cache.get(blockchain_name)
    
    async def insert_snapshot(
        self,
        blockchain_name: str,
        tier_name: str,
        snapshot_date: datetime,
        address_count: int,
        total_balance: Decimal,
        balance_change_24h: Optional[Decimal] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        插入單筆地址分層快照
        
        Args:
            blockchain_name: 區塊鏈名稱（'BTC', 'ETH'）
            tier_name: 分層名稱（'0-1', '1-10', ...）
            snapshot_date: 快照日期時間
            address_count: 地址數量
            total_balance: 總持幣量
            balance_change_24h: 24小時變動（可選）
            metadata: 元數據（可選）
        
        Returns:
            是否成功插入
        """
        blockchain_id = self._get_blockchain_id(blockchain_name)
        tier_id = self._get_tier_id(tier_name)
        
        if blockchain_id is None:
            logger.error(f"未知的區塊鏈: {blockchain_name}")
            return False
        
        if tier_id is None:
            logger.error(f"未知的分層: {tier_name}")
            return False
        
        # 計算平均持幣量
        avg_balance = total_balance / address_count if address_count > 0 else Decimal('0')
        
        insert_query = """
        INSERT INTO address_tier_snapshots (
            snapshot_date, blockchain_id, tier_id,
            address_count, total_balance, avg_balance,
            balance_change_24h, data_source, metadata
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        ON CONFLICT (blockchain_id, snapshot_date, tier_id) 
        DO UPDATE SET
            address_count = EXCLUDED.address_count,
            total_balance = EXCLUDED.total_balance,
            avg_balance = EXCLUDED.avg_balance,
            balance_change_24h = EXCLUDED.balance_change_24h,
            metadata = EXCLUDED.metadata,
            updated_at = NOW()
        """
        
        try:
            async with self.conn_pool.acquire() as conn:
                await conn.execute(
                    insert_query,
                    snapshot_date,
                    blockchain_id,
                    tier_id,
                    address_count,
                    float(total_balance),
                    float(avg_balance),
                    float(balance_change_24h) if balance_change_24h else None,
                    'glassnode',
                    metadata
                )
            
            return True
        
        except Exception as e:
            logger.error(f"插入快照失敗: {e}")
            return False
    
    async def insert_snapshots_batch(
        self,
        blockchain_name: str,
        snapshots: List[Dict[str, Any]]
    ) -> int:
        """
        批量插入地址分層快照
        
        Args:
            blockchain_name: 區塊鏈名稱
            snapshots: 快照列表 [{
                'tier_name': '0-1',
                'snapshot_date': datetime,
                'address_count': 1234,
                'total_balance': Decimal('123.456'),
                'balance_change_24h': Decimal('1.23'),
                'metadata': {}
            }, ...]
        
        Returns:
            成功插入的數量
        """
        blockchain_id = self._get_blockchain_id(blockchain_name)
        if blockchain_id is None:
            logger.error(f"未知的區塊鏈: {blockchain_name}")
            return 0
        
        success_count = 0
        
        for snapshot in snapshots:
            tier_id = self._get_tier_id(snapshot['tier_name'])
            if tier_id is None:
                logger.warning(f"跳過未知分層: {snapshot['tier_name']}")
                continue
            
            # 計算平均持幣量
            address_count = snapshot['address_count']
            total_balance = snapshot['total_balance']
            avg_balance = total_balance / address_count if address_count > 0 else Decimal('0')
            
            try:
                async with self.conn_pool.acquire() as conn:
                    await conn.execute(
                        """
                        INSERT INTO address_tier_snapshots (
                            snapshot_date, blockchain_id, tier_id,
                            address_count, total_balance, avg_balance,
                            balance_change_24h, data_source, metadata
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                        ON CONFLICT (blockchain_id, snapshot_date, tier_id) 
                        DO UPDATE SET
                            address_count = EXCLUDED.address_count,
                            total_balance = EXCLUDED.total_balance,
                            avg_balance = EXCLUDED.avg_balance,
                            balance_change_24h = EXCLUDED.balance_change_24h,
                            metadata = EXCLUDED.metadata,
                            updated_at = NOW()
                        """,
                        snapshot['snapshot_date'],
                        blockchain_id,
                        tier_id,
                        address_count,
                        float(total_balance),
                        float(avg_balance),
                        float(snapshot.get('balance_change_24h', 0)) if snapshot.get('balance_change_24h') else None,
                        'glassnode',
                        json.dumps(snapshot.get('metadata')) if isinstance(snapshot.get('metadata'), dict) else snapshot.get('metadata')
                    )
                
                success_count += 1
            
            except Exception as e:
                logger.error(
                    f"插入失敗 ({snapshot['tier_name']} @ "
                    f"{snapshot['snapshot_date'].strftime('%Y-%m-%d')}): {e}"
                )
                continue
        
        return success_count
    
    async def get_previous_snapshot(
        self,
        blockchain_name: str,
        tier_name: str,
        before_date: datetime
    ) -> Optional[Dict[str, Any]]:
        """
        取得特定分層在特定日期之前的最新快照（用於計算變動）
        
        Args:
            blockchain_name: 區塊鏈名稱
            tier_name: 分層名稱
            before_date: 基準日期
        
        Returns:
            快照資料或 None
        """
        blockchain_id = self._get_blockchain_id(blockchain_name)
        tier_id = self._get_tier_id(tier_name)
        
        if blockchain_id is None or tier_id is None:
            return None
        
        query = """
        SELECT 
            snapshot_date,
            address_count,
            total_balance,
            balance_change_24h
        FROM address_tier_snapshots
        WHERE blockchain_id = $1
          AND tier_id = $2
          AND snapshot_date < $3
        ORDER BY snapshot_date DESC
        LIMIT 1
        """
        
        try:
            async with self.conn_pool.acquire() as conn:
                row = await conn.fetchrow(query, blockchain_id, tier_id, before_date)
                
                if row:
                    return {
                        'snapshot_date': row['snapshot_date'],
                        'address_count': row['address_count'],
                        'total_balance': Decimal(str(row['total_balance'])),
                        'balance_change_24h': Decimal(str(row['balance_change_24h'])) if row['balance_change_24h'] else None,
                    }
        
        except Exception as e:
            logger.error(f"查詢前一天快照失敗: {e}")
        
        return None
    
    async def update_percentages(
        self,
        blockchain_name: str,
        snapshot_date: datetime
    ):
        """
        更新特定日期所有分層的百分比統計
        
        計算:
        - balance_pct: 佔總流通量百分比
        - address_pct: 佔總地址數百分比
        """
        blockchain_id = self._get_blockchain_id(blockchain_name)
        if blockchain_id is None:
            return
        
        update_query = """
        WITH totals AS (
            SELECT 
                SUM(total_balance) AS total_supply,
                SUM(address_count) AS total_addresses
            FROM address_tier_snapshots
            WHERE blockchain_id = $1
              AND DATE(snapshot_date) = $2
        )
        UPDATE address_tier_snapshots ats
        SET 
            balance_pct = CASE 
                WHEN t.total_supply > 0 THEN (ats.total_balance / t.total_supply * 100)::NUMERIC(5,2)
                ELSE NULL
            END,
            address_pct = CASE 
                WHEN t.total_addresses > 0 THEN (ats.address_count::NUMERIC / t.total_addresses * 100)::NUMERIC(5,2)
                ELSE NULL
            END,
            updated_at = NOW()
        FROM totals t
        WHERE ats.blockchain_id = $1
          AND DATE(ats.snapshot_date) = $2
        """
        
        try:
            async with self.conn_pool.acquire() as conn:
                result = await conn.execute(update_query, blockchain_id, snapshot_date.date())
                logger.debug(f"更新百分比統計: {result}")
        
        except Exception as e:
            logger.error(f"更新百分比失敗: {e}")


# ============================================
# 測試程式
# ============================================

async def test_address_tier_loader():
    """測試地址分層載入器"""
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    db_config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'port': int(os.getenv('DB_PORT', 5432)),
        'user': os.getenv('DB_USER', 'crypto'),
        'password': os.getenv('DB_PASSWORD', ''),
        'database': os.getenv('DB_NAME', 'crypto_db'),
    }
    
    loader = AddressTierLoader(db_config)
    
    try:
        await loader.connect()
        
        # 測試插入單筆快照
        logger.info("測試插入單筆快照...")
        success = await loader.insert_snapshot(
            blockchain_name='BTC',
            tier_name='100-1K',
            snapshot_date=datetime.now(),
            address_count=123456,
            total_balance=Decimal('54321.12345678'),
            balance_change_24h=Decimal('123.45')
        )
        
        if success:
            logger.success("✅ 單筆插入成功")
        else:
            logger.error("❌ 單筆插入失敗")
        
        # 測試批量插入
        logger.info("\n測試批量插入...")
        snapshots = [
            {
                'tier_name': '0-1',
                'snapshot_date': datetime.now(),
                'address_count': 10000000,
                'total_balance': Decimal('500000.0'),
                'balance_change_24h': Decimal('-100.0'),
            },
            {
                'tier_name': '1-10',
                'snapshot_date': datetime.now(),
                'address_date': 500000,
                'total_balance': Decimal('1500000.0'),
                'balance_change_24h': Decimal('50.0'),
            }
        ]
        
        count = await loader.insert_snapshots_batch('BTC', snapshots)
        logger.success(f"✅ 批量插入成功: {count} 筆")
        
        # 測試更新百分比
        logger.info("\n測試更新百分比...")
        await loader.update_percentages('BTC', datetime.now())
        logger.success("✅ 百分比更新完成")
    
    except Exception as e:
        logger.error(f"❌ 測試失敗: {e}")
        raise
    
    finally:
        await loader.close()


if __name__ == "__main__":
    asyncio.run(test_address_tier_loader())
