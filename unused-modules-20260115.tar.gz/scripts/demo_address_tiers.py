#!/usr/bin/env python3
"""
BTC 地址分層追蹤 - Demo 展示
使用模擬資料展示輸出效果（不需要實際 API）
"""
from datetime import datetime, timedelta
from decimal import Decimal
from rich.console import Console
from rich.table import Table
from rich.text import Text
from typing import Dict, List, Any


def generate_demo_data(days: int = 5) -> Dict[str, Any]:
    """生成模擬資料"""
    
    # 定義分層與基礎數據（簡化版：4 層）
    tiers = {
        '0-1': {
            'display_order': 1,
            'base_balance': Decimal('1387528'),
            'base_addresses': 48500000,
            'volatility': 1000  # 每日波動範圍
        },
        '1-10': {
            'display_order': 2,
            'base_balance': Decimal('2089601'),
            'base_addresses': 850000,
            'volatility': 800
        },
        '10-100': {
            'display_order': 3,
            'base_balance': Decimal('4302751'),
            'base_addresses': 145000,
            'volatility': 2000
        },
        '100+': {
            'display_order': 4,
            'base_balance': Decimal('21708116'),  # 合併 100-1K + 1K-10K + 10K+
            'base_addresses': 16350,              # 合併地址數
            'volatility': 4000                    # 更高波動
        }
    }
    
    # 生成每日變動數據（模擬真實市場）
    import random
    random.seed(42)  # 固定種子以保持一致性
    
    dates = []
    base_date = datetime.now()
    
    for i in range(days):
        date = base_date - timedelta(days=i)
        dates.append(date.strftime('%m/%d'))
    
    # 為每個分層生成資料
    tiers_data = {}
    
    for tier_name, tier_config in tiers.items():
        tier_data = []
        
        for date_str in dates:
            # 模擬每日變動（有正有負，符合市場行為）
            change = random.randint(-tier_config['volatility'], tier_config['volatility'])
            
            # 100+ 層級通常流入較多（巨鯨買入）
            if tier_name == '100+' and random.random() > 0.4:
                change = abs(change)  # 60% 機率為正數
            
            # 0-1 層級通常流出較多（散戶賣出）
            if tier_name == '0-1' and random.random() > 0.4:
                change = -abs(change)  # 60% 機率為負數
            
            tier_data.append({
                'date': date_str,
                'change': Decimal(str(change))
            })
        
        tiers_data[tier_name] = {
            'display_order': tier_config['display_order'],
            'balance': tier_config['base_balance'],
            'address_count': tier_config['base_addresses'],
            'data': tier_data
        }
    
    return {
        'dates': dates,
        'tiers': tiers_data
    }


def format_number(value: Decimal, decimals: int = 0) -> str:
    """格式化數字（加千分位）"""
    if decimals == 0:
        return f"{int(value):,}"
    else:
        return f"{float(value):,.{decimals}f}"


def format_change(change: Decimal) -> Text:
    """格式化變動數字（帶顏色與符號）"""
    if change > 0:
        return Text(f"+{int(change)} BTC", style="bold green")
    elif change < 0:
        return Text(f"{int(change)} BTC", style="bold red")
    else:
        return Text("0 BTC", style="dim")


def display_demo_table():
    """顯示 Demo 表格"""
    console = Console()
    
    # 生成模擬資料
    data = generate_demo_data(days=5)
    
    # 建立表格
    current_time = datetime.now().strftime('%H:%M')
    table = Table(
        title=f"\n[bold yellow on black] BTC 鏈上數據 [/bold yellow on black]                                      [bold white]{current_time}[/bold white]",
        title_justify="center",
        show_header=True,
        header_style="bold white on blue",
        border_style="bright_black",
        padding=(0, 1),
        expand=True
    )
    
    console.print()
    
    # 添加欄位
    table.add_column("BTC\nAddress Tiers", style="cyan bold", width=20)
    table.add_column("BTC held", style="white bold", justify="right", width=18)
    
    for date_str in data['dates']:
        table.add_column(date_str, justify="center", width=15)
    
    # 排序分層（按 display_order）
    sorted_tiers = sorted(
        data['tiers'].items(),
        key=lambda x: x[1]['display_order']
    )
    
    # 添加資料行
    for tier_name, tier_info in sorted_tiers:
        tier_label = f"({tier_name})Coins"
        total_balance = format_number(tier_info['balance'], decimals=0)
        
        row: List[Any] = [tier_label, total_balance]
        
        # 建立日期 -> 變動的映射
        date_map = {item['date']: item for item in tier_info['data']}
        
        for date_str in data['dates']:
            if date_str in date_map:
                change = date_map[date_str]['change']
                row.append(format_change(change))
            else:
                row.append(Text("N/A", style="dim"))
        
        table.add_row(*row)
    
    # 顯示表格
    console.print(table)
    console.print()
    
    # 顯示統計摘要
    console.print("\n[bold cyan]📊 資料摘要[/bold cyan]")
    console.print(f"  • 監控分層: {len(data['tiers'])} 個")
    console.print(f"  • 追蹤天數: {len(data['dates'])} 天")
    console.print(f"  • 總流通量: ~{sum(t['balance'] for t in data['tiers'].values()):,.0f} BTC")
    console.print()
    
    # 顯示重點觀察
    console.print("[bold yellow]🔍 重點觀察[/bold yellow]")
    console.print("  • [green]綠色[/green] = 流入/增加（買入訊號）")
    console.print("  • [red]紅色[/red] = 流出/減少（賣出訊號）")
    console.print("  • [bold]巨鯨層級 (100+)[/bold] 持續流入 → 看漲訊號")
    console.print("  • [bold]散戶層級 (0-1)[/bold] 持續流出 → 恐慌性賣出")
    console.print()


if __name__ == "__main__":
    display_demo_table()
