#!/usr/bin/env python3
"""
BTC 地址分層追蹤 - 終端輸出工具

顯示類似 YouTube 頻道風格的 BTC 地址持幣量變動表格
"""
import asyncio
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List
from decimal import Decimal

# 添加專案路徑
sys.path.insert(0, str(Path(__file__).parent / 'src'))

import asyncpg
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.text import Text


class AddressTierDisplay:
    """地址分層顯示器"""
    
    def __init__(self, db_config: Dict[str, Any]):
        self.db_config = db_config
        self.conn_pool = None
        self.console = Console()
    
    async def connect(self):
        """建立資料庫連接"""
        self.conn_pool = await asyncpg.create_pool(
            host=self.db_config.get('host', 'localhost'),
            port=self.db_config.get('port', 5432),
            user=self.db_config.get('user', 'crypto'),
            password=self.db_config.get('password', ''),
            database=self.db_config.get('database', 'crypto_db'),
            min_size=1,
            max_size=5
        )
    
    async def close(self):
        """關閉連接"""
        if self.conn_pool:
            await self.conn_pool.close()
    
    async def get_tier_data(
        self,
        blockchain: str = 'BTC',
        days: int = 5
    ) -> Dict[str, Any]:
        """
        取得過去 N 天的地址分層資料
        
        Returns:
            {
                'dates': ['2025-01-15', '2025-01-14', ...],
                'tiers': {
                    '0-1': {
                        'display_order': 1,
                        'balance': Decimal(...),
                        'data': [
                            {'date': '2025-01-15', 'balance': Decimal(...), 'change': Decimal(...)},
                            ...
                        ]
                    },
                    ...
                }
            }
        """
        query = """
        SELECT 
            DATE(ats.snapshot_date) AS snapshot_date,
            at.tier_name,
            at.display_order,
            ats.total_balance,
            ats.address_count,
            ats.balance_change_24h
        FROM address_tier_snapshots ats
        JOIN blockchains b ON ats.blockchain_id = b.id
        JOIN address_tiers at ON ats.tier_id = at.id
        WHERE b.name = $1
          AND ats.snapshot_date >= NOW() - INTERVAL '1 day' * $2
        ORDER BY ats.snapshot_date DESC, at.display_order
        """
        
        if self.conn_pool is None:
            raise RuntimeError("資料庫連接未建立")
        
        async with self.conn_pool.acquire() as conn:
            rows = await conn.fetch(query, blockchain, days)
        
        if not rows:
            return {'dates': [], 'tiers': {}}
        
        # 組織資料
        dates: List[str] = []
        tiers_data: Dict[str, Any] = {}
        
        for row in rows:
            date_str = row['snapshot_date'].strftime('%m/%d')
            tier_name = row['tier_name']
            
            if date_str not in dates:
                dates.append(date_str)
            
            if tier_name not in tiers_data:
                tiers_data[tier_name] = {
                    'display_order': row['display_order'],
                    'balance': Decimal(str(row['total_balance'])),
                    'data': []
                }
            
            tiers_data[tier_name]['data'].append({
                'date': date_str,
                'balance': Decimal(str(row['total_balance'])),
                'change': Decimal(str(row['balance_change_24h'])) if row['balance_change_24h'] else Decimal('0'),
                'address_count': row['address_count']
            })
        
        return {'dates': dates, 'tiers': tiers_data}
    
    def format_number(self, value: Decimal, decimals: int = 0) -> str:
        """格式化數字（加千分位）"""
        if decimals == 0:
            return f"{int(value):,}"
        else:
            return f"{float(value):,.{decimals}f}"
    
    def format_change(self, change: Decimal) -> Text:
        """
        格式化變動數字（帶顏色與符號）
        
        綠色: 正數（流入/增加）
        紅色: 負數（流出/減少）
        """
        if change > 0:
            return Text(f"+{int(change)} BTC", style="bold green")
        elif change < 0:
            return Text(f"{int(change)} BTC", style="bold red")
        else:
            return Text("0 BTC", style="dim")
    
    async def display_table(
        self,
        blockchain: str = 'BTC',
        days: int = 5
    ):
        """顯示地址分層表格"""
        
        # 取得資料
        data = await self.get_tier_data(blockchain, days)
        
        if not data['dates']:
            self.console.print("[red]❌ 無可用資料[/red]")
            return
        
        # 建立表格
        table = Table(
            title=f"\n[bold yellow on black] {blockchain} 鏈上數據 [/bold yellow on black]",
            title_justify="center",
            show_header=True,
            header_style="bold white on blue",
            border_style="bright_black",
            title_style="bold yellow",
            padding=(0, 1)
        )
        
        # 添加時間戳（右上角）
        current_time = datetime.now().strftime('%H:%M')
        
        # 添加欄位
        table.add_column(f"{blockchain}\nAddress Tiers", style="cyan bold", width=20)
        table.add_column(f"{blockchain} held", style="white bold", justify="right", width=18)
        
        dates_list = data.get('dates', [])
        for date_str in dates_list:
            table.add_column(str(date_str), justify="center", width=15)
        
        # 排序分層（按 display_order）
        tiers_dict = data.get('tiers', {})
        sorted_tiers = sorted(
            tiers_dict.items(),
            key=lambda x: x[1]['display_order']
        )
        
        # 添加資料行
        for tier_name, tier_info in sorted_tiers:
            tier_label = f"({tier_name})Coins"
            total_balance = self.format_number(tier_info['balance'], decimals=0)
            
            row: List[Any] = [tier_label, total_balance]
            
            # 建立日期 -> 變動的映射
            date_map = {item['date']: item for item in tier_info['data']}
            
            for date_str in dates_list:
                if date_str in date_map:
                    change = date_map[date_str]['change']
                    row.append(self.format_change(change))
                else:
                    row.append(Text("N/A", style="dim"))
            
            table.add_row(*row)
        
        # 顯示表格
        self.console.print()
        self.console.print(table)
        self.console.print()
        self.console.print(
            f"[dim]資料來源: Glassnode API | 更新時間: {current_time}[/dim]",
            justify="right"
        )
        self.console.print(
            "[dim]註: 排除非行為性噪聲樣本[/dim]",
            justify="right"
        )
        self.console.print()
    
    async def display_summary(self, blockchain: str = 'BTC'):
        """顯示簡要統計"""
        query = """
        SELECT 
            at.tier_name,
            ats.total_balance,
            ats.address_count,
            ats.balance_change_24h,
            ats.balance_pct
        FROM address_tier_snapshots ats
        JOIN blockchains b ON ats.blockchain_id = b.id
        JOIN address_tiers at ON ats.tier_id = at.id
        WHERE b.name = $1
          AND DATE(ats.snapshot_date) = CURRENT_DATE
        ORDER BY at.display_order
        """
        
        if self.conn_pool is None:
            raise RuntimeError("資料庫連接未建立")
        
        async with self.conn_pool.acquire() as conn:
            rows = await conn.fetch(query, blockchain)
        
        if not rows:
            self.console.print("[yellow]⚠️  今日尚無資料[/yellow]")
            return
        
        # 建立表格
        table = Table(
            title=f"[bold cyan]{blockchain} 地址分層統計（今日）[/bold cyan]",
            show_header=True,
            header_style="bold magenta"
        )
        
        table.add_column("分層", style="cyan")
        table.add_column("地址數量", justify="right", style="white")
        table.add_column("總持幣量", justify="right", style="yellow")
        table.add_column("24h 變動", justify="right")
        table.add_column("佔比", justify="right", style="green")
        
        for row in rows:
            tier_name = f"({row['tier_name']}) Coins"
            address_count = self.format_number(Decimal(str(row['address_count'])))
            total_balance = self.format_number(Decimal(str(row['total_balance']))) + " BTC"
            
            change_24h = Decimal(str(row['balance_change_24h'])) if row['balance_change_24h'] else Decimal('0')
            change_text = self.format_change(change_24h)
            
            balance_pct = f"{float(row['balance_pct']):.2f}%" if row['balance_pct'] else "N/A"
            
            table.add_row(tier_name, address_count, total_balance, change_text, balance_pct)
        
        self.console.print()
        self.console.print(table)
        self.console.print()


async def main():
    """主程式"""
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    db_config = {
        'host': os.getenv('DB_HOST') or os.getenv('POSTGRES_HOST', 'localhost'),
        'port': int(os.getenv('DB_PORT') or os.getenv('POSTGRES_PORT', 5432)),
        'user': os.getenv('DB_USER') or os.getenv('POSTGRES_USER', 'crypto'),
        'password': os.getenv('DB_PASSWORD') or os.getenv('POSTGRES_PASSWORD', ''),
        'database': os.getenv('DB_NAME') or os.getenv('POSTGRES_DB', 'crypto_db'),
    }
    
    display = AddressTierDisplay(db_config)
    
    try:
        await display.connect()
        
        # 顯示表格（類似 YouTube 頻道風格）
        await display.display_table(blockchain='BTC', days=5)
        
        # 顯示詳細統計
        await display.display_summary(blockchain='BTC')
    
    except Exception as e:
        logger.error(f"❌ 顯示失敗: {e}")
        raise
    
    finally:
        await display.close()


if __name__ == "__main__":
    asyncio.run(main())
